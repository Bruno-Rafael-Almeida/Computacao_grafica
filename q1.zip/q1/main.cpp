#include <GL/gl.h>
#include <GL/glut.h>

float win;                          // win (window), vai definir o tamanho de cada viewport (quanto maior valor de win, mais longe da tela)
float aspecto;                      // aspecto: vari�vel para controlar windowsize
int largura, altura;                //largura e altura da minha janela

void hexagono(){
    glLineWidth(8);
    glColor3f(0,1,0);
    glBegin(GL_POLYGON);
        glVertex2f(-8.0, -8.0);
        glVertex2f(-16.0, 0.0);
        glVertex2f(-8.0, 8.0);
         glColor3f(0,0,1);
        glVertex2f(8.0, 8.0);
        glVertex2f(16.0, 0.0);
        glVertex2f(8.0, -8.0);
    glEnd();
}

void pontos(){
    glPointSize(6);
    glBegin(GL_POINTS);
        glColor3f(1,0,0);
        glVertex2f(-8.0, -8.0);
        glVertex2f(-16.0, 0.0);
        glVertex2f(-8.0, 8.0);
         glColor3f(0,0,1);
        glVertex2f(8.0, 8.0);
        glVertex2f(16.0, 0.0);
        glVertex2f(8.0, -8.0);
    glEnd();
}

void contorno(){                            //desenha linhas para ter melhor visualiza��o das viewports
    glLineWidth(2);                         //adiciona espessura da linha
    glBegin(GL_LINE_LOOP);                  //lBegin e glEnd delimitam os v�rtices que definem uma primitiva ou um grupo de primitivas semelhantes (definida como par�metro).
        glColor3f(0,0,0);                   //adiciona cor na linha
        glVertex2f(-win*aspecto, -win);     //inferior esquerdo
        glVertex2f(-win*aspecto, win);      //superior esquerdo
        glVertex2f(win*aspecto, win);       //superior direito
        glVertex2f(win*aspecto, -win);      //inferior direito
    glEnd();
}

void desenhaObjetos(void){
    glClear(GL_COLOR_BUFFER_BIT);


	glViewport(0, 0, largura, altura);
	glPushMatrix();
        contorno();
        glRotatef(30,0,0,1);
         glScalef(2, 2, 0);
        pontos();
		hexagono();
	 glPopMatrix();

	glViewport(largura, 0, largura, altura);
    glPushMatrix();
		contorno();
	 glPopMatrix();

	glutSwapBuffers();
}

void alteraTamanhoJanela(GLsizei w, GLsizei h){
    if(h == 0) h = 1;
    largura = w/2;
    altura = h;

    aspecto = (float) largura / altura;

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-win*aspecto, win*aspecto, -win, win);
}

void inicializa(){
     glClearColor(1,1,1,0);
     win = 50;
}

int main(void){
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);          //somente um double buffer | sistema de cores RGB
    glutInitWindowSize(800,600);                          //define o tamanho da janela
    glutInitWindowPosition(320,150);                      //medidas usadas para posicionar a janela no meio da tela - isso depende da resolu��o do monitor
	glutCreateWindow("Exemplo Viewport");                 //permite a cria��o de uma janela
    glutDisplayFunc(desenhaObjetos);                      //fun��o de callback - chama a fun��o desenhaObjetos
    glutReshapeFunc(alteraTamanhoJanela);                 //fun��o que altera o tamanho da janela, redesenha o tamanho da janela
    inicializa();
    glutMainLoop();                                       //loop infinito - escuta as informa��es do sistema at� encerrar a aplica��o
    return 0;                                             //retorna zero
}
